import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer>
    <Link to="/cart">
      BE Shop
    </Link>
  </footer>
  )
}
